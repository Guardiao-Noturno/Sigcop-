
document.addEventListener("DOMContentLoaded", function () {
    let funcionarios = JSON.parse(localStorage.getItem("funcionarios")) || [];
    let usuarioLogado = null;

    const admin = { username: "Jean", password: "2017", type: "admin" };

    const escalaSelect = document.getElementById("escala");
    for (let i = 1; i <= 31; i++) {
        const option = document.createElement("option");
        option.value = i;
        option.textContent = i;
        escalaSelect.appendChild(option);
    }

    function atualizarTabela() {
        const escalaTable = document.getElementById("escala-table");
        escalaTable.innerHTML = "";

        funcionarios.forEach(funcionario => {
            let row = document.createElement("tr");
            row.innerHTML = `
                <td>${funcionario.name}</td>
                <td>${funcionario.matricula}</td>
                <td>${funcionario.escala}/${funcionario.mes}/${funcionario.ano}</td>
                <td>
                    ${usuarioLogado === "admin" ? `
                        <button class="btn btn-warning btn-sm edit-button" data-id="${funcionario.matricula}">Editar</button>
                        <button class="btn btn-danger btn-sm delete-button" data-id="${funcionario.matricula}">Excluir</button>
                    ` : ""}
                </td>
            `;
            escalaTable.appendChild(row);
        });

        if (usuarioLogado === "admin") {
            document.querySelectorAll(".delete-button").forEach(button => {
                button.addEventListener("click", excluirFuncionario);
            });

            document.querySelectorAll(".edit-button").forEach(button => {
                button.addEventListener("click", editarFuncionario);
            });

            document.getElementById("voltar-admin").classList.remove("d-none"); // Mostra botão para admin
        } else {
            document.getElementById("voltar-admin").classList.add("d-none"); // Oculta botão para funcionário
        }
    }

    document.getElementById("login-button").addEventListener("click", function () {
        const username = document.getElementById("username").value.trim();
        const password = document.getElementById("password").value.trim();
        const userType = document.getElementById("user-type").value;

        if (!userType) {
            alert("Selecione o tipo de usuário!");
            return;
        }

        if (userType === "admin" && username === admin.username && password === admin.password) {
            usuarioLogado = "admin";
            document.getElementById("login-container").classList.add("d-none");
            document.getElementById("admin-container").classList.remove("d-none");
        } else {
            let funcionario = funcionarios.find(f => f.matricula === username && f.password === password);

            if (funcionario) {
                usuarioLogado = "funcionario";
                document.getElementById("login-container").classList.add("d-none");
                document.getElementById("escala-container").classList.remove("d-none");
                document.getElementById("voltar-admin").classList.add("d-none"); // Oculta botão para funcionário
                atualizarTabela();
            } else {
                alert("Usuário ou senha incorretos!");
            }
        }
    });

    document.getElementById("add-funcionario").addEventListener("click", function () {
        let nome = document.getElementById("name").value.trim();
        let matricula = document.getElementById("matricula").value.trim();
        let escala = document.getElementById("escala").value;
        let mes = document.getElementById("mes").value;
        let ano = document.getElementById("ano").value;

        if (!nome || !matricula || !escala || !mes || !ano) {
            alert("Preencha todos os campos!");
            return;
        }

        let novoFuncionario = { name: nome, matricula, escala, mes, ano, password: "1234" };

        funcionarios.push(novoFuncionario);
        localStorage.setItem("funcionarios", JSON.stringify(funcionarios));

        atualizarTabela();
        document.getElementById("cadastro-form").reset();
        alert("Funcionário cadastrado com sucesso! A senha padrão é 1234.");
    });

    document.getElementById("logout-admin").addEventListener("click", function () {
        usuarioLogado = null;
        document.getElementById("admin-container").classList.add("d-none");
        document.getElementById("login-container").classList.remove("d-none");
    });

    document.getElementById("logout-funcionario").addEventListener("click", function () {
        usuarioLogado = null;
        document.getElementById("escala-container").classList.add("d-none");
        document.getElementById("login-container").classList.remove("d-none");
    });

    function excluirFuncionario(event) {
        const matricula = event.target.getAttribute("data-id");
        funcionarios = funcionarios.filter(f => f.matricula !== matricula);
        localStorage.setItem("funcionarios", JSON.stringify(funcionarios));
        atualizarTabela();
    }

    function editarFuncionario(event) {
        const matricula = event.target.getAttribute("data-id");
        const funcionario = funcionarios.find(f => f.matricula === matricula);

        if (funcionario) {
            document.getElementById("name").value = funcionario.name;
            document.getElementById("matricula").value = funcionario.matricula;
            document.getElementById("escala").value = funcionario.escala;
            document.getElementById("mes").value = funcionario.mes;
            document.getElementById("ano").value = funcionario.ano;

            funcionarios = funcionarios.filter(f => f.matricula !== matricula);
            localStorage.setItem("funcionarios", JSON.stringify(funcionarios));
        }
    }

    document.getElementById("ver-escala").addEventListener("click", function () {
        document.getElementById("admin-container").classList.add("d-none");
        document.getElementById("escala-container").classList.remove("d-none");
        atualizarTabela();
    });

    document.getElementById("voltar-admin").addEventListener("click", function () {
        document.getElementById("escala-container").classList.add("d-none");
        document.getElementById("admin-container").classList.remove("d-none");
    });

    atualizarTabela();
});